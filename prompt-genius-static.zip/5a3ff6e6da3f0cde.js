(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,59544,e=>{"use strict";var t=e.i(43476);function a({children:e,variant:a="primary",size:i="md",isLoading:s=!1,icon:r,className:n="",disabled:o,...l}){return(0,t.jsxs)("button",{className:`inline-flex items-center justify-center gap-2 font-medium rounded-lg transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--accent)] ${{primary:"bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] shadow-sm",secondary:"bg-[var(--bg-primary)] text-[var(--text-primary)] border border-[var(--border)] hover:bg-[var(--bg-tertiary)]",ghost:"text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] hover:text-[var(--text-primary)]",danger:"bg-[var(--danger)] text-white hover:opacity-90"}[a]} ${{sm:"px-3 py-1.5 text-sm",md:"px-4 py-2 text-sm",lg:"px-6 py-3 text-base"}[i]} ${n}`,disabled:o||s,...l,children:[s?(0,t.jsxs)("svg",{className:"animate-spin h-4 w-4",viewBox:"0 0 24 24",children:[(0,t.jsx)("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4",fill:"none"}),(0,t.jsx)("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"})]}):r||null,e]})}e.s(["default",()=>a])},72520,e=>{"use strict";let t=(0,e.i(75254).default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);e.s(["ArrowRight",()=>t],72520)},74886,e=>{"use strict";let t=(0,e.i(75254).default)("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);e.s(["Copy",()=>t],74886)},56909,e=>{"use strict";let t=(0,e.i(75254).default)("save",[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]]);e.s(["Save",()=>t],56909)},67240,e=>{"use strict";let t=(0,e.i(75254).default)("rotate-ccw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);e.s(["RotateCcw",()=>t],67240)},41240,e=>{"use strict";let t=(0,e.i(75254).default)("lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]);e.s(["Lightbulb",()=>t],41240)},85208,e=>{"use strict";function t(e,a="general",i=[]){let s,r,n,o,l,c,d=e.trim();if(!d)return{optimizedPrompt:"",improvements:[],model:a};let u=[],p=(s=d.toLowerCase(),/(write|create|compose|draft|generate).*(blog|article|post|essay|content)/i.test(s)?"content_creation":/(write|create|compose|draft|generate).*(email|message|letter)/i.test(s)?"communication":/(code|program|function|script|build|develop|implement|debug|fix)/i.test(s)?"coding":/(explain|teach|describe|what is|how does|define)/i.test(s)?"explanation":/(analyze|evaluate|review|assess|compare|critique)/i.test(s)?"analysis":/(plan|strategy|roadmap|outline|brainstorm|idea)/i.test(s)?"planning":/(design|ui|ux|layout|mockup|wireframe)/i.test(s)?"design":/(market|seo|advertis|campaign|brand|social media)/i.test(s)?"marketing":/(data|sql|database|query|csv|spreadsheet|chart)/i.test(s)?"data":/(translate|convert|transform|rewrite|rephrase|summarize)/i.test(s)?"transformation":"general"),m=function(e){let t=e.match(/(?:about|on|regarding|for|of)\s+(.+?)(?:\.|$|\n|,\s*(?:and|with|using|that|which|including))/i);if(t)return t[1].trim();let a=e.match(/(?:write|create|explain|analyze|build|design|generate|make|develop|plan)\s+(?:a|an|the|some|my)?\s*(.+?)(?:\.|$|\n)/i);return a?a[1].trim():e.slice(0,80)}(d),h=[];h.push("I need you to carefully follow every instruction below to produce an outstanding, high-quality result. Please adhere to each section precisely."),h.push((r={content_creation:`You are a seasoned content strategist and professional writer with 10+ years of experience in the field of content creation. You specialize in crafting pieces about ${m} that captivate readers from the first sentence and deliver genuine value throughout.`,communication:`You are an expert business communication specialist and professional in the field of corporate messaging. You understand the nuances of audience, context, and purpose in every piece of writing about ${m}.`,coding:`You are a senior software engineer and domain expert in the field of software development. You write production-ready code with thorough error handling, documentation, and performance considerations for ${m}.`,explanation:`You are a world-class educator and subject matter expert in the field of knowledge communication. You break down ${m} into digestible, logical layers — using analogies, real-world examples, and progressive complexity to ensure deep understanding.`,analysis:`You are a rigorous analytical consultant and expert in the field of critical evaluation. You approach ${m} with objectivity, thoroughness, and a keen eye for both strengths and weaknesses.`,planning:`You are a strategic planning consultant and expert in the field of project management. You think about ${m} holistically — considering risks, dependencies, resources, and measurable outcomes.`,design:`You are a senior UX/UI designer and expert in the field of human-centered design. You approach ${m} with both creative vision and practical usability in mind.`,marketing:`You are a growth-oriented marketing strategist and expert in the field of digital marketing. You craft ${m}-related strategies that resonate with target audiences and drive measurable results.`,data:`You are a senior data analyst and expert in the field of data science. You approach ${m} with statistical rigor, clear visualization thinking, and business-relevant interpretation.`,transformation:`You are a skilled linguistic specialist and expert in the field of content adaptation. You handle ${m} with precision, nuance, and attention to preserving meaning.`,general:`You are an exceptionally knowledgeable and versatile expert in the field of ${m}. You approach every task with thoroughness, precision, and a commitment to delivering genuinely useful, well-structured responses.`},`## Role & Expertise
${r[p]||r.general}`)),u.push(`Assigned expert role matched to "${p.replace(/_/g," ")}" intent`),h.push((o=(n={content_creation:`produce compelling, high-quality content about ${m} that engages and informs the reader`,communication:`craft a clear, effective message regarding ${m} that achieves its communication objective`,coding:`develop a robust, well-documented solution for ${m} that meets production standards`,explanation:`provide a thorough, accessible explanation of ${m} that builds genuine understanding`,analysis:`deliver a comprehensive, evidence-based analysis of ${m} with actionable insights`,planning:`create a detailed, actionable plan for ${m} with clear milestones and success criteria`,design:`design an intuitive, user-centered solution for ${m} that balances aesthetics and usability`,marketing:`develop a data-driven marketing strategy for ${m} that drives measurable results`,data:`extract meaningful, actionable insights from ${m} with clear data-driven conclusions`,transformation:`accurately transform the content about ${m} while preserving meaning and intent`,general:`deliver a thorough, expert-level response about ${m} that exceeds expectations`})[p]||n.general,`## Context & Background
Consider the full context and background of this task. The primary goal and objective is to ${o}. Your audience includes readers and users who expect clear, well-structured, and insightful information in this subject domain. Tailor your response to be valuable for both intermediate and advanced users in this field.`)),u.push("Added comprehensive context with audience, purpose, and domain framing");let g=i.filter(e=>e.isActive);if(g.length>0){let e="## Project Context\n"+g.map(e=>`### ${e.name}
${e.content}`).join("\n\n");h.push(e),u.push(`Injected ${g.length} project context(s) for personalization`)}h.push(`## Task
${d}`+((l={content_creation:`

## Content Requirements
- Open with a compelling hook that immediately grabs attention
- Structure with clear, descriptive headings and subheadings (H2, H3)
- Include 3-5 specific, real-world examples, case studies, or data points to support each key argument
- Write in an engaging, conversational yet authoritative tone and style
- Follow a clear step-by-step process: research, outline, draft, refine
- Each section should flow naturally into the next with smooth transitions
- End with a powerful conclusion that includes actionable takeaways
- Aim for comprehensive coverage — do not skim the surface`,communication:`

## Communication Requirements
- Lead with the most important information (inverted pyramid structure)
- Use a tone and style appropriate to the relationship and context
- Follow a clear step-by-step process for the message flow
- Be specific and concise but complete — every sentence must earn its place
- Include 2-3 concrete examples to illustrate key points
- Include a clear call-to-action or next steps
- Anticipate questions and address them proactively`,coding:`

## Code Requirements
- Write clean, production-ready code with meaningful variable and function names
- Include comprehensive inline comments explaining the "why" behind complex logic
- Add robust error handling and input validation with specific edge cases
- Follow a clear step-by-step process: plan, implement, test, document
- Consider 3-5 edge cases, performance implications, and security concerns
- Provide usage examples showing how to call and use the code
- If applicable, suggest specific tests that should be written
- Follow current best practices and idiomatic style for the language`,explanation:`

## Explanation Requirements
- Start with a high-level overview (the "what" and "why it matters")
- Break the explanation into a clear step-by-step process with progressive layers of depth
- Use at least 3 specific, concrete analogies or real-world examples
- Define technical terms when first introduced in a clear tone and style
- Include a "Common Misconceptions" section if applicable
- End with a summary and "Next Steps for Learning"`,analysis:`

## Analysis Requirements
- Begin with an executive summary of 3-5 specific key findings
- Use a structured analytical framework (SWOT, pros/cons, criteria-based, etc.)
- Follow a clear step-by-step process for your analytical approach
- Support every claim with specific evidence, data, or logical reasoning — include examples
- Address counterarguments and limitations honestly in an objective tone and style
- Provide 5+ specific, actionable recommendations ranked by priority
- Include a risk assessment where relevant`,planning:`

## Planning Requirements
- Define clear objectives with specific, measurable success criteria (SMART goals)
- Break down into phases using a clear step-by-step process with milestones and timelines
- Include 3-5 specific examples of deliverables for each phase
- Identify required resources, tools, and dependencies with exact quantities
- Include a risk assessment with mitigation strategies in a structured style
- Define KPIs or metrics to track progress
- Provide contingency plans with specific triggers and appropriate tone for communication`,design:`

## Design Requirements
- Consider 2-3 specific user personas and their primary goals with examples
- Follow accessibility standards (WCAG 2.1 AA minimum) — include specific requirements
- Apply visual hierarchy principles and consistent spacing in your style
- Follow a step-by-step process: research, wireframe, design, validate
- Describe interactive states (hover, focus, active, disabled) in a clear tone
- Consider responsive behavior across 3+ breakpoints
- Provide rationale for major design decisions`,marketing:`

## Marketing Requirements
- Define the target audience with 3+ specific demographics and psychographics examples
- Craft messaging that addresses specific pain points in an authentic tone and style
- Follow a clear step-by-step process for campaign development
- Include channel-specific strategies with platform best practices
- Suggest 3-5 specific A/B testing hypotheses for key elements
- Provide success metrics and tracking recommendations with exact numbers
- Include a timeline with specific launch milestones`,data:`

## Data Requirements
- Describe the data schema, types, and any specific assumptions with examples
- Write optimized, readable queries with inline comments in a clean style
- Follow a step-by-step process: explore, clean, analyze, visualize
- Include 3-5 specific data validation and cleaning steps
- Provide visualization recommendations with chart type reasoning and tone guidance
- Highlight statistical significance considerations with specific thresholds
- Suggest 2-3 follow-up analyses that could deepen insights`,transformation:`

## Transformation Requirements
- Preserve the original meaning, intent, and specific key information
- Follow a step-by-step process: analyze source, adapt, verify accuracy
- Adapt the tone and style to the target format and audience with examples
- Highlight any ambiguities in the source and how you resolved them
- Maintain consistent terminology throughout
- Provide 2-3 specific examples of how critical passages were transformed`,general:`

## Quality Requirements
- Be thorough and comprehensive — cover all relevant aspects with specific detail
- Follow a clear step-by-step process in your response structure
- Use 3-5 specific examples, data points, or evidence to support your points
- Write in a clear, professional tone and style
- Organize information with clear headings and logical flow
- Anticipate follow-up questions and address them proactively
- Provide actionable insights, not just information`})[p]||l.general)),u.push(`Added ${p.replace(/_/g," ")} specific requirements and quality criteria`),h.push(`## Creative Approach
- Explore unique angles and brainstorm creative solutions that make the output truly stand out
- Use analogy and metaphor where they aid understanding and engagement
- Offer fresh perspectives and innovative viewpoints that go beyond the obvious
- Combine established knowledge with novel connections to deliver original insights
- Make every section genuinely valuable — aim to exceed expectations!!`),u.push("Added creative direction for unique, high-impact output"),h.push((c={content_creation:`## Output Format
- Use structured **Markdown** with proper heading hierarchy (H2, H3)
- Include **bold** for key terms and emphasis
- Use bullet points or numbered lists for scannable sections
- Add a TL;DR summary at the top
- Separate major sections with clear headings
- Target length: comprehensive (1500+ words for full articles)`,coding:`## Output Format
- Use structured fenced code blocks with language identifiers
- Organize code with clear section comments in Markdown format
- After the code, provide:
  1. **How to use** — brief usage instructions with bullet points
  2. **Key decisions** — explain architectural choices
  3. **Edge cases** — what to watch out for
  4. **Improvements** — potential future enhancements`,explanation:`## Output Format
- Start with a structured **1-2 sentence TL;DR** in Markdown format
- Use a layered structure: Overview > Details > Deep Dive with bullet points
- Include **callout boxes** for important notes (> blockquotes)
- Use diagrams or ASCII art if it aids understanding
- End with a **Quick Reference** summary table`,analysis:`## Output Format
- Begin with a structured **Executive Summary** (3-5 sentences) in Markdown format
- Use a well-organized framework with labeled sections and bullet points
- Include comparison tables where relevant
- Rate or score items on consistent scales
- End with **Prioritized Recommendations** as a numbered list`,planning:`## Output Format
- Present as a structured phased roadmap with clear timeline in Markdown format
- Use tables for milestones, deadlines, and ownership with bullet points
- Include checklist items for actionable steps
- Provide a visual overview (ASCII timeline or Gantt-style)
- End with **Success Metrics** and **Risk Register**`,general:`## Output Format
- Use structured **Markdown** formatting with clear headings and sections
- Include bullet points for key lists and takeaways
- Use **bold** for important terms and concepts
- Add examples in blockquotes or code blocks where helpful
- End with a concise **Summary** or **Key Takeaways** section`})[p]||c.general),u.push("Defined structured output format with formatting guidelines"),h.push(`## Constraints & Scope
Within the scope and constraints of this task, you must adhere to these required standards:
- **Accuracy**: Every claim must be factually correct and defensible
- **Depth**: Go beyond surface-level — provide genuine expert-level insight
- **Clarity**: Use precise language; avoid jargon unless defined
- **Actionability**: Every section should give the reader something they can act on
- **Originality**: Provide fresh perspectives, not generic recycled content
- Do NOT use filler phrases like "In today's world..." or "It's important to note that..."
- Do NOT be vague — replace generalities with specifics, numbers, and concrete examples
- Stay within the defined scope and respect the stated constraints and boundaries
- Ensure all content is required quality — no padding, no fluff, every word must earn its place`),u.push("Added strict quality constraints with scope boundaries"),/(how to|explain|tutorial|guide|plan|strategy)/i.test(d)&&(h.push("## Approach\nBreak this down into clear, numbered steps. Explain the reasoning behind each step before moving to the next. Ensure every step is specific and actionable."),u.push("Added explicit step-by-step reasoning instruction")),/(beginner|student|child|kid|non-technical|simple)/i.test(d)?(h.push("## Audience Note\nThe reader is a beginner or non-technical user. Avoid jargon, use simple analogies, and build understanding from first principles."),u.push("Calibrated language level for beginner audience")):/(advanced|expert|senior|technical|professional)/i.test(d)&&(h.push("## Audience Note\nThe reader is an advanced professional user. Skip basics, use precise technical terminology, and focus on nuanced, expert-level insights."),u.push("Calibrated language level for expert audience"));let f={chatgpt:`

## Model Optimization (ChatGPT)
- Use markdown formatting extensively — headers, bold, lists, tables
- Leverage your training in structured reasoning
- When uncertain, explicitly state confidence levels
- Use code blocks for any technical content`,claude:`

## Model Optimization (Claude)
- Think through your reasoning step by step before answering
- Use your strength in nuanced, balanced analysis
- Be willing to express uncertainty and present multiple perspectives
- Provide your chain of thought for complex problems`,gemini:`

## Model Optimization (Gemini)
- Draw on your broad, up-to-date knowledge base
- Provide multiple perspectives with source-style attributions
- Use your multimodal understanding for richer descriptions
- Include practical, real-world applications`,copilot:`

## Model Optimization (Copilot)
- Prioritize practical, immediately-usable code solutions
- Include complete, runnable code examples
- Add inline documentation following language conventions
- Suggest relevant libraries, tools, or extensions`,llama:`

## Model Optimization (LLaMA)
- Be concise but thorough — optimize for information density
- Use clear structural markers (headers, numbered lists)
- Focus on practical, directly applicable advice
- Avoid overly long preambles — get to the substance quickly`,general:""}[a]||"";return f&&(h.push(f),u.push(`Optimized prompt structure for ${a} model`)),{optimizedPrompt:h.join("\n\n---\n\n"),improvements:u,model:a}}function a(e){return e.split(/\s+/).filter(Boolean).length}function i(e){let t,i,s,r,n,o,l=e.trim();if(!l)return{overallScore:0,clarity:0,specificity:0,context:0,actionability:0,creativity:0,feedback:"Please enter a prompt to evaluate.",suggestions:[]};let c=(t=50,(i=a(l))>10&&(t+=10),i>30&&(t+=10),/[.!?]/.test(l)&&(t+=10),/^[A-Z]/.test(l)&&(t+=5),/(please|could you|can you|I need|I want)/i.test(l)&&(t+=5),/\n/.test(l)&&(t+=10),Math.min(t,100)),d=(s=40,/\d+/.test(l)&&(s+=10),/(specific|exactly|precise|particular)/i.test(l)&&(s+=10),/(example|e\.g\.|such as|like|for instance)/i.test(l)&&(s+=10),/(format|structure|json|markdown|bullet|table)/i.test(l)&&(s+=10),a(l)>50&&(s+=10),/(must|should|need to|required)/i.test(l)&&(s+=10),Math.min(s,100)),u=(r=30,/(background|context|scenario|situation)/i.test(l)&&(r+=15),/(you are|act as|role|expert|professional)/i.test(l)&&(r+=15),/(audience|reader|user|client)/i.test(l)&&(r+=10),/(purpose|goal|objective|aim)/i.test(l)&&(r+=10),a(l)>100&&(r+=10),/(industry|field|domain|subject)/i.test(l)&&(r+=10),Math.min(r,100)),p=(n=40,/(create|write|generate|build|design|develop|make)/i.test(l)&&(n+=15),/(step|steps|process|procedure|instructions)/i.test(l)&&(n+=10),/(output|result|deliverable|produce)/i.test(l)&&(n+=10),/(tone|style|voice|approach)/i.test(l)&&(n+=10),/(limit|constraint|boundary|scope)/i.test(l)&&(n+=10),/\d/.test(l)&&(n+=5),Math.min(n,100)),m=(o=50,/(unique|creative|innovative|original|novel)/i.test(l)&&(o+=10),/(imagine|brainstorm|explore|what if)/i.test(l)&&(o+=10),/(metaphor|analogy|story|narrative)/i.test(l)&&(o+=10),/(perspective|viewpoint|angle|approach)/i.test(l)&&(o+=10),a(l)>75&&(o+=5),/[!?]{2,}/.test(l)&&(o+=5),Math.min(o,100)),h=Math.round(.25*c+.25*d+.2*u+.2*p+.1*m),g=[],f=[];return c<60&&(g.push("Add proper punctuation and sentence structure for better clarity."),f.push("Clarity needs improvement.")),d<60&&(g.push("Include specific details, numbers, or examples to make your prompt more precise."),f.push("Prompt lacks specificity.")),u<50&&(g.push('Add context such as role ("You are an expert..."), audience, or background information.'),f.push("Missing context and role definition.")),p<50&&(g.push("Include clear action verbs and specify the desired output format."),f.push("Could be more actionable.")),m<50&&g.push('Try adding creative framing like "Imagine..." or "What if..." for more engaging results.'),15>a(l)&&g.push("Consider making your prompt longer with more detail and requirements."),!/\n/.test(l)&&a(l)>30&&g.push("Break your prompt into multiple lines or sections for better readability."),h>=80?f.unshift("Excellent prompt! Well-structured and detailed."):h>=60?f.unshift("Good prompt with room for improvement."):h>=40?f.unshift("Average prompt. Consider the suggestions below."):f.unshift("This prompt needs significant improvement."),{overallScore:h,clarity:c,specificity:d,context:u,actionability:p,creativity:m,feedback:f.join(" "),suggestions:g}}e.s(["evaluatePrompt",()=>i,"optimizePrompt",()=>t])},20016,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(33060),s=e.i(74886),r=e.i(56909),n=e.i(67240),o=e.i(69638);let l=(0,e.i(75254).default)("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);var c=e.i(83086),d=e.i(72520),u=e.i(41240),p=e.i(59544),m=e.i(88840),h=e.i(85208),g=e.i(27225);let f=[{value:"general",label:"General (All Models)"},{value:"chatgpt",label:"ChatGPT"},{value:"claude",label:"Claude"},{value:"gemini",label:"Gemini"},{value:"copilot",label:"Copilot"},{value:"llama",label:"LLaMA"}],v=["Write a professional email to a client about a project delay","Create a marketing plan for a new SaaS product launch","Explain quantum computing to a 10-year-old","Generate a code review checklist for a React application"];function b(){let[e,b]=(0,a.useState)(""),[y,x]=(0,a.useState)("general"),[w,k]=(0,a.useState)(null),[j,z]=(0,a.useState)(!1),[N,C]=(0,a.useState)(!1);return(0,a.useEffect)(()=>{let e=sessionStorage.getItem("pg_optimize_input");e&&(b(e),sessionStorage.removeItem("pg_optimize_input"))},[]),(0,t.jsxs)("div",{className:"max-w-5xl mx-auto space-y-6 animate-fadeIn",children:[(0,t.jsx)("div",{className:"bg-gradient-to-r from-emerald-500/10 to-teal-500/10 rounded-xl p-5 border border-emerald-200 dark:border-emerald-900/50",children:(0,t.jsxs)("div",{className:"flex items-center gap-3 mb-2",children:[(0,t.jsx)("div",{className:"w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center",children:(0,t.jsx)(i.Wand2,{size:20,className:"text-white"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h2",{className:"font-semibold text-lg",children:"Prompt Optimizer"}),(0,t.jsx)("p",{className:"text-sm text-[var(--text-secondary)]",children:"Transform basic prompts into powerful, optimized Super Prompts"})]})]})}),(0,t.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",children:[(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"bg-[var(--bg-primary)] rounded-xl border border-[var(--border)] p-5",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[(0,t.jsx)("label",{className:"font-medium text-sm",children:"Your Prompt"}),(0,t.jsxs)("span",{className:"text-xs text-[var(--text-tertiary)]",children:[e.length," chars"]})]}),(0,t.jsx)("textarea",{value:e,onChange:e=>b(e.target.value),placeholder:"Enter your prompt here... e.g., 'Write a blog post about AI in healthcare'",className:"w-full min-h-[200px] p-3 rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] text-sm resize-y focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent"}),(0,t.jsxs)("div",{className:"mt-3",children:[(0,t.jsx)("label",{className:"text-sm font-medium mb-1.5 block",children:"Target AI Model"}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)("select",{value:y,onChange:e=>x(e.target.value),className:"w-full appearance-none px-4 py-2.5 rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] text-sm cursor-pointer focus:outline-none focus:ring-2 focus:ring-[var(--accent)]",children:f.map(e=>(0,t.jsx)("option",{value:e.value,children:e.label},e.value))}),(0,t.jsx)(l,{size:16,className:"absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)] pointer-events-none"})]})]}),(0,t.jsxs)("div",{className:"flex gap-2 mt-4",children:[(0,t.jsx)(p.default,{onClick:()=>{e.trim()?(z(!0),C(!1),setTimeout(()=>{let t=(0,g.getContexts)();k((0,h.optimizePrompt)(e,y,t)),z(!1),(0,m.toast)("success","Prompt optimized successfully!")},1200)):(0,m.toast)("error","Please enter a prompt to optimize")},isLoading:j,icon:(0,t.jsx)(c.Sparkles,{size:16}),className:"flex-1",children:"Optimize"}),(0,t.jsx)(p.default,{variant:"ghost",onClick:()=>{b(""),k(null),C(!1)},icon:(0,t.jsx)(n.RotateCcw,{size:16}),children:"Reset"})]})]}),(0,t.jsxs)("div",{className:"bg-[var(--bg-primary)] rounded-xl border border-[var(--border)] p-5",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 mb-3",children:[(0,t.jsx)(u.Lightbulb,{size:16,className:"text-amber-500"}),(0,t.jsx)("span",{className:"font-medium text-sm",children:"Try These"})]}),(0,t.jsx)("div",{className:"space-y-2",children:v.map((e,a)=>(0,t.jsx)("button",{onClick:()=>b(e),className:"w-full text-left text-sm p-2.5 rounded-lg border border-[var(--border)] hover:border-[var(--accent)] hover:bg-[var(--accent-light)] transition-all duration-200 cursor-pointer",children:e},a))})]})]}),(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"bg-[var(--bg-primary)] rounded-xl border border-[var(--border)] p-5",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[(0,t.jsxs)("label",{className:"font-medium text-sm flex items-center gap-2",children:[(0,t.jsx)(c.Sparkles,{size:16,className:"text-[var(--accent)]"}),"Optimized Super Prompt"]}),w&&(0,t.jsxs)("div",{className:"flex gap-1",children:[(0,t.jsx)("button",{onClick:()=>{w&&(navigator.clipboard.writeText(w.optimizedPrompt),(0,m.toast)("success","Copied to clipboard!"))},className:"p-1.5 rounded-lg hover:bg-[var(--bg-tertiary)] transition-colors cursor-pointer",title:"Copy",children:(0,t.jsx)(s.Copy,{size:16})}),(0,t.jsx)("button",{onClick:()=>{if(w){let t=(0,g.getUser)();(0,g.savePrompt)({userId:t?.id||"",title:e.slice(0,60)+(e.length>60?"...":""),originalPrompt:e,optimizedPrompt:w.optimizedPrompt,category:"optimized",tags:[y],folderId:null,isFavorite:!1,score:null,model:y}),C(!0),(0,m.toast)("success","Prompt saved to library!")}},disabled:N,className:"p-1.5 rounded-lg hover:bg-[var(--bg-tertiary)] transition-colors cursor-pointer disabled:opacity-50",title:"Save",children:N?(0,t.jsx)(o.CheckCircle,{size:16,className:"text-[var(--success)]"}):(0,t.jsx)(r.Save,{size:16})})]})]}),j?(0,t.jsx)("div",{className:"min-h-[200px] flex items-center justify-center",children:(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"w-12 h-12 border-4 border-[var(--accent)] border-t-transparent rounded-full animate-spin mx-auto mb-3"}),(0,t.jsx)("p",{className:"text-sm text-[var(--text-secondary)]",children:"Optimizing your prompt..."})]})}):w?(0,t.jsx)("div",{className:"min-h-[200px] p-3 rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] text-sm whitespace-pre-wrap animate-fadeIn",children:w.optimizedPrompt}):(0,t.jsx)("div",{className:"min-h-[200px] flex items-center justify-center text-[var(--text-tertiary)] text-sm",children:(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)(d.ArrowRight,{size:32,className:"mx-auto mb-2 opacity-30"}),(0,t.jsx)("p",{children:"Your optimized prompt will appear here"})]})})]}),w&&w.improvements.length>0&&(0,t.jsxs)("div",{className:"bg-[var(--bg-primary)] rounded-xl border border-[var(--border)] p-5 animate-fadeIn",children:[(0,t.jsxs)("h3",{className:"font-medium text-sm mb-3 flex items-center gap-2",children:[(0,t.jsx)(o.CheckCircle,{size:16,className:"text-[var(--success)]"}),"Improvements Applied"]}),(0,t.jsx)("ul",{className:"space-y-2",children:w.improvements.map((e,a)=>(0,t.jsxs)("li",{className:"flex items-start gap-2 text-sm text-[var(--text-secondary)]",children:[(0,t.jsx)("div",{className:"w-1.5 h-1.5 rounded-full bg-[var(--success)] mt-1.5 shrink-0"}),e]},a))})]})]})]})]})}e.s(["default",()=>b],20016)}]);